"""[MIA NOTE] 2026-10-09 — Genesis Python SDK package root."""
__version__ = "0.1.0.dev0"
