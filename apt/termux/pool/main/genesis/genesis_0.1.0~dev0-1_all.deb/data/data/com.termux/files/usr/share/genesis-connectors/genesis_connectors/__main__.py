"""[MIA NOTE] 2026-10-09 — Allow python -m genesis_connectors as alternate CLI entry."""
from .cli import main

if __name__ == "__main__":
    raise SystemExit(main())
