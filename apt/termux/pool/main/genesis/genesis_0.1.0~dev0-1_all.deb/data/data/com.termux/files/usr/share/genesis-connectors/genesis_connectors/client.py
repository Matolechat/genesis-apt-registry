"""[MIA NOTE] 2026-10-09 — Secure Genesis HTTP SDK transport for CLI.
WHY: client operations must never leak bearer credentials or follow redirects.
This is a development client. Customer OAuth scopes are not yet implemented.
"""
from __future__ import annotations

import json
import re
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import (
    HTTPRedirectHandler,
    Request,
    build_opener,
)

JOB_ID = re.compile(r"^genjob_[a-f0-9-]{36}$")
DEFAULT_BASE_URL = "https://api.genesisconnectors.tech"


class GenesisApiError(RuntimeError):
    """An API or local transport operation failed; never includes secrets."""


class _RejectRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class GenesisClient:
    def __init__(
        self,
        base_url: str = DEFAULT_BASE_URL,
        token: str | None = None,
        timeout: float = 15.0,
    ) -> None:
        url = urlsplit(base_url)
        local = url.hostname in {"127.0.0.1", "localhost", "::1"}
        if (
            url.scheme not in {"http", "https"}
            or (url.scheme == "http" and not local)
            or not url.hostname
            or url.username is not None
            or url.password is not None
            or url.query
            or url.fragment
            or (url.path not in {"", "/"})
        ):
            raise ValueError("Base URL must be HTTPS or loopback HTTP, with no path or credentials")
        if not isinstance(timeout, (int, float)) or not (0 < timeout <= 120):
            raise ValueError("Timeout must be between 0 and 120 seconds")
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.timeout = timeout
        self._opener = build_opener(_RejectRedirect())

    def request(
        self,
        method: str,
        path: str,
        payload: dict | None = None,
        *,
        authenticated: bool = False,
    ) -> dict:
        if not path.startswith("/") or "//" in path or ".." in path or "?" in path or "#" in path:
            raise ValueError("Invalid request path")
        if authenticated and not self.token:
            raise GenesisApiError("Authentication required: set GENESIS_API_TOKEN in your environment")
        headers = {"Accept": "application/json", "User-Agent": "genesis-connectors-cli/0.1.0.dev0"}
        if authenticated:
            headers["Authorization"] = "Bearer " + self.token
        data = None
        if payload is not None:
            data = json.dumps(payload, separators=(",", ":"), allow_nan=False).encode("utf-8")
            headers["Content-Type"] = "application/json"
        req = Request(self.base_url + path, data=data, headers=headers, method=method)
        try:
            with self._opener.open(req, timeout=self.timeout) as response:
                raw = response.read(4 * 1024 * 1024 + 1)
                if len(raw) > 4 * 1024 * 1024:
                    raise GenesisApiError("API response exceeds 4 MiB client limit")
                obj = json.loads(raw.decode("utf-8"))
                if not isinstance(obj, dict):
                    raise GenesisApiError("Unexpected API response shape")
                return obj
        except HTTPError as error:
            # [MIA NOTE] 2026-10-09 — Close error bodies to prevent socket/FD leaks on long polling.
            # Suppress raw body and redirect Location: either may contain secrets.
            status = error.code
            error.close()
            raise GenesisApiError("Genesis API returned HTTP " + str(status)) from None
        except (URLError, TimeoutError, OSError) as error:
            # Do not print raw error: some proxy/network exceptions include userinfo.
            raise GenesisApiError("Genesis API unreachable or TLS verification failed") from None
        except (UnicodeError, json.JSONDecodeError):
            raise GenesisApiError("Genesis API did not return valid JSON") from None

    @staticmethod
    def safe_id(job_id: str) -> str:
        if not JOB_ID.fullmatch(job_id):
            raise ValueError("Invalid Genesis job ID")
        return job_id

    def health(self) -> dict:
        return self.request("GET", "/health")

    def providers(self) -> dict:
        return self.request("GET", "/providers")

    def submit(self, *, kind: str, parameters: dict, idempotency_key: str | None = None) -> dict:
        body = {"kind": kind, "parameters": parameters}
        if idempotency_key:
            body["idempotencyKey"] = idempotency_key
        return self.request("POST", "/compute/jobs", body, authenticated=True)

    def list_jobs(self) -> dict:
        return self.request("GET", "/compute/jobs", authenticated=True)

    def status(self, job_id: str) -> dict:
        return self.request("GET", "/compute/jobs/" + self.safe_id(job_id), authenticated=True)

    def result(self, job_id: str) -> dict:
        return self.request("GET", "/compute/jobs/" + self.safe_id(job_id) + "/result", authenticated=True)

    def cancel(self, job_id: str) -> dict:
        return self.request("POST", "/compute/jobs/" + self.safe_id(job_id) + "/cancel", authenticated=True)
