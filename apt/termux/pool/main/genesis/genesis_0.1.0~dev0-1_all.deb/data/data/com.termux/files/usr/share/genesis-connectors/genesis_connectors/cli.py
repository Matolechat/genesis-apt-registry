"""[MIA NOTE] 2026-10-09 — CLI entry point for Genesis Connectors.
Provides bounded compute operations; all remote state lives on the Genesis service.
Not an unattended background client. No secrets are saved to disk.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time

from .client import DEFAULT_BASE_URL, GenesisApiError, GenesisClient


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="genesis",
        description="Genesis Connectors — MCP, providers, and durable scientific compute",
    )
    parser.add_argument("--base-url", default=os.environ.get("GENESIS_API_BASE", DEFAULT_BASE_URL))
    parser.add_argument("--json", action="store_true", help="Compact machine-readable JSON")
    parser.add_argument("--timeout", type=float, default=15.0, help="HTTP request timeout (seconds)")
    parser.add_argument("--version", action="version", version="genesis-connectors-cli 0.1.0.dev0")
    commands = parser.add_subparsers(dest="command", required=True)

    commands.add_parser("health", help="Read Genesis API health")
    commands.add_parser("doctor", help="Diagnose public API connectivity without secrets")
    commands.add_parser("providers", help="List known Genesis provider capabilities")

    compute = commands.add_parser("compute", help="Durable local-first scientific jobs")
    operations = compute.add_subparsers(dest="action", required=True)
    submit = operations.add_parser("submit", help="Submit an allowlisted numerical cosmology job")
    submit.add_argument("--h0", type=float, default=70)
    submit.add_argument("--omega-matter", type=float, default=0.3)
    submit.add_argument("--omega-radiation", type=float, default=0)
    submit.add_argument("--z-max", type=float, default=1)
    submit.add_argument("--steps", type=int, default=10000)
    submit.add_argument("--idempotency-key", help="Retry-safe user-defined key")

    operations.add_parser("list", help="List jobs accessible to the authenticated principal")
    for action in ("status", "result", "cancel"):
        sub = operations.add_parser(action, help=action.title()+" a durable Genesis job")
        sub.add_argument("job_id", help="Job identifier returned by compute submit")

    wait = operations.add_parser("wait", help="Poll for completion; server compute runs independently")
    wait.add_argument("job_id")
    wait.add_argument("--poll-seconds", type=float, default=5)
    wait.add_argument("--timeout-seconds", type=float, default=3600)
    return parser


def _await_job(client: GenesisClient, job_id: str, poll: float, total: float) -> dict:
    if poll < 0.5 or poll > 300 or total < poll or total > 604800:
        raise ValueError("Polling interval/timeout out of bounds")
    end = time.monotonic() + total
    while True:
        response = client.status(job_id)
        job = response.get("job") or {}
        state = job.get("status")
        if state == "SUCCEEDED":
            return client.result(job_id)
        if state in {"FAILED", "CANCELLED"}:
            return response
        if time.monotonic() >= end:
            raise GenesisApiError("Local polling timed out; server job can continue independently")
        time.sleep(min(poll, max(0, end - time.monotonic())))


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        client = GenesisClient(
            base_url=args.base_url,
            token=os.environ.get("GENESIS_API_TOKEN"),
            timeout=args.timeout,
        )
        if args.command == "health":
            result = client.health()
        elif args.command == "providers":
            result = client.providers()
        elif args.command == "doctor":
            try:
                health = client.health()
                result = {
                    "apiReachable": True,
                    "apiReportedHealthy": health.get("ok") is True,
                    "baseUrl": client.base_url,
                    "note": "Health does not prove that compute or providers are public or connected.",
                }
            except GenesisApiError:
                result = {
                    "apiReachable": False,
                    "apiReportedHealthy": False,
                    "baseUrl": client.base_url,
                    "note": "Public DNS/HTTPS may be unfinished; verify ingress before advertising a live product.",
                }
        elif args.command == "compute":
            if args.action == "submit":
                result = client.submit(
                    kind="cosmology.lcdm_lookback",
                    parameters={
                        "h0": args.h0,
                        "omegaMatter": args.omega_matter,
                        "omegaRadiation": args.omega_radiation,
                        "zMax": args.z_max,
                        "steps": args.steps,
                    },
                    idempotency_key=args.idempotency_key,
                )
            elif args.action == "list":
                result = client.list_jobs()
            elif args.action == "status":
                result = client.status(args.job_id)
            elif args.action == "result":
                result = client.result(args.job_id)
            elif args.action == "cancel":
                result = client.cancel(args.job_id)
            elif args.action == "wait":
                result = _await_job(client, args.job_id, args.poll_seconds, args.timeout_seconds)
            else:
                parser.error("unknown compute command")
        else:
            parser.error("unknown command")
        print(json.dumps(result, ensure_ascii=False, sort_keys=True,
                         separators=(",", ":") if args.json else None,
                         indent=None if args.json else 2))
        if args.command == "doctor" and not result.get("apiReachable"):
            return 3
        return 0
    except (GenesisApiError, ValueError) as error:
        print(json.dumps({"ok": False, "error": str(error)}, ensure_ascii=False), file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print(json.dumps({"ok": False, "error": "Polling interrupted; server job unchanged"}), file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
